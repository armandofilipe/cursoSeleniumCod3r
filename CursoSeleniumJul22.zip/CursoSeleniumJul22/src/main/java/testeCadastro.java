
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


// Uso da notação JUnit "@Before" e "@After". Isso faz com que tenhamos pré-execuções e pós-execuções padrão.
//Declaração de uma variável global driver
public class testeCadastro {
	
	private WebDriver driver;
	private CampoTreinamentoPage page;
//-------------------------------------------------------------------------------------------------------------------------------------
	
	@Before
	public void inicializa() {	
		driver = new FirefoxDriver();
		driver.get("file:///"+System.getProperty("user.dir")+"/src/main/resources/componentes.html");	
		page = new CampoTreinamentoPage(driver);
	}
	
	@After
	public void finaliza() {
		driver.quit();
	}
	
//-------------------------------------------------------------------------------------------------------------------------------------
		
		
	//Desafio: Cadastro completo-----------------------------
	@Test
	public void deveRealizarCadastroComSucesso() {
		
		page.setNome("Armando");
		page.setSobrenome("Cruz");
		page.setSexoMasculino();
		page.setComidaPizza();
		page.setEsciolaridade("Mestrado");
		page.setEsporte("Natacao");
		page.cadastrar();
		
		
		Assert.assertTrue(page.obterResultadoCadastro().startsWith("Cadastrado!"));
		Assert.assertTrue(page.obterNomeCadastro().endsWith("Armando"));
		Assert.assertEquals("Sobrenome: Cruz", page.obterSobrenomeCadastro());
		Assert.assertEquals("Sexo: Masculino", page.obterSexoCadastro());
		Assert.assertEquals("Comida: Pizza", page.obterComidaCadastro());
		Assert.assertEquals("Escolaridade: mestrado", page.obterEscolaridadeCadastro());
		Assert.assertEquals("Esportes: Natacao", page.obterEsportesCadastro());
	}
	
	
}