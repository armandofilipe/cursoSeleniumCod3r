
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

public class TesteCampoTreinamento {
	
	private WebDriver driver;
	private DSL dsl;
//-------------------------------------------------------------------------------------------------------------------------------------
	@Before
	public void inicializa() {
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///"+System.getProperty("user.dir")+"/src/main/resources/componentes.html");
		dsl = new DSL(driver);
		
	}
	
	//@After
	//public void finaliza() {
		
	//	driver.quit();
		
	//}
//-------------------------------------------------------------------------------------------------------------------------------------
	
	@Test
	public void testeTextField() {
		
		dsl.escrever("elementosForm:nome", "Teste de escrita");
		//driver.findElement(By.id("elementosForm:nome")).sendKeys("Teste de escrita");
		
		Assert.assertEquals("Teste de escrita", dsl.obterValorCampo("elementosForm:nome"));
		//Assert.assertEquals("Teste de escrita", driver.findElement(By.id("elementosForm:nome")).getAttribute("value"));

	}
	
	@Test
	public void testeDeveInteragirComtextArea() {
		
		dsl.escrever("elementosForm:sugestoes", "Qualquer coisa \n aqui neste campo de texto.");
		Assert.assertEquals("Qualquer coisa \n aqui neste campo de texto.", dsl.obterValorCampo("elementosForm:sugestoes"));
	}
	
	@Test
	public void deveInteragirComRadioButton() {
		
		dsl.clicarRadio("elementosForm:sexo:0");
		Assert.assertTrue(dsl.isRadioMarcado("elementosForm:sexo:0"));
	}
	
	@Test
	public void deveInteragirComCheckBox() {
		
		dsl.clicarRadio("elementosForm:comidaFavorita:2");
		Assert.assertTrue(dsl.isCheckMarcado("elementosForm:comidaFavorita:2"));
	}
	
	@Test
	public void deveInteragirComCombo() {
		dsl.selecionarCombo("elementosForm:escolaridade", "2o grau completo");
		Assert.assertEquals("2o grau completo", dsl.obterValorCombo("elementosForm:escolaridade"));
			
	}
	
	
	@Test
	public void deveVerificarValoresCombo() {
		
		Assert.assertEquals(8,dsl.obterQuantidadeOpcoesCombo("elementosForm:escolaridade"));
		Assert.assertTrue(dsl.verificarOpcaoComboString("elementosForm:escolaridade", "Mestrado"));
		
	}

	@Test
	public void deveVerificarValoresComboMultiplo() {
		dsl.selecionarCombo("elementosForm:esportes", "Natacao");
		dsl.selecionarCombo("elementosForm:esportes", "Corrida");
		dsl.selecionarCombo("elementosForm:esportes", "O que eh esporte?");
		List<String> opcoesMarcadas = dsl.obterValoresCombo("elementosForm:esportes");
		Assert.assertEquals(3, opcoesMarcadas.size());
		dsl.desselecionarCombo("elementosForm:esportes","Corrida");
		opcoesMarcadas = dsl.obterValoresCombo("elementosForm:esportes");
		Assert.assertEquals(2, opcoesMarcadas.size());
		opcoesMarcadas.containsAll(Arrays.asList("Natacao", "O que eh esporte?"));
		
	}

	@Test
	public void deveinteragirComBotoes() {
		
		dsl.clicarBotao("buttonSimple");
		Assert.assertEquals("Obrigado!", dsl.obterValueElemento("buttonSimple"));
	}
	
	@Test
	public void deveinteragirComLinks() {
		dsl.clicarLink("Voltar");
		Assert.assertEquals("Voltou!", dsl.obterTexto("resultado"));
	}
	
	@Test
	public void deveBuscarTextosNaPagina() {
		Assert.assertEquals("Campo de Treinamento", dsl.obterTexto(By.tagName("h3")));
		Assert.assertEquals("Cuidado onde clica, muitas armadilhas...",dsl.obterTexto(By.className("facilAchar")));
	}
	
	//JavaScript
	
	@Test
	public void testJavascript() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("alert('Testando js via selenium')");

		//js.executeScript("document.getElementById('elementosForm:nome').value = 'Escrito via js'");
		//js.executeScript("document.getElementById('elementosForm:sobrenome').type = 'radio'");
	}
	
//end
}


